=====================================================
Lens Print Service - Installation Instructions
=====================================================

1. Double-click "run_silent.vbs" to start the printer service silently in the background.
2. The service runs on port 9333 and connects with Lens Web.

Automatic Windows Startup (Recommended):
- Press Win + R on your keyboard.
- Type "shell:startup" and press Enter.
- Create a shortcut to "run_silent.vbs" and paste it into the Startup folder.

Resetting / Troubleshooting:
- If you need to reset settings or clear cache, run "LensPrintService-Reset.exe".
